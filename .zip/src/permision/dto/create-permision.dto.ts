export class CreatePermisionDto {}
